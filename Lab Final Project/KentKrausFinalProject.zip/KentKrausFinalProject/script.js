window.onload = function() {
	document.getElementById("modified").innerHTML = "This document was last modified on: " + document.lastModified;
}